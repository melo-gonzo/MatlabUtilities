This is SNAKE!
There is some functionality to save high scores and total amout of time played
To set this up, first create a folder where you want to save the high score and time played.
In the command window, type:
te = 0
save PATH_TO_YOUR_FOLDER\te te
High_Score = 0
save PATH_TO_YOUR_FOLDER\High_Score

Next, make sure to update the save paths for these in lines 7/8/133/135

If you want to save a video of your performance, set:
video = 1

If you want to watch the computer play, set:
computer = 1

Enjoy, and feel free to add suggestions or make changes yourself!